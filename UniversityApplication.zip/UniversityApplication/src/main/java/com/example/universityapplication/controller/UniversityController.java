package com.example.universityapplication.controller;

import com.example.universityapplication.pojo.dto.University;
import com.example.universityapplication.service.UniversityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class UniversityController {

    @Autowired
    UniversityService universityService;

    @GetMapping("/universities")
    public ResponseEntity<List<University>> getAll() {
        return new ResponseEntity<>(universityService.getAllUniversities(), HttpStatus.OK);

    }

    @PostMapping("/universities")
    public ResponseEntity<List<University>> getByMultipleCountries(@RequestBody List<String> countries) {
        return new ResponseEntity<>(universityService.getUniversitiesForMultipleCountries(countries), HttpStatus.OK);
    }
}
