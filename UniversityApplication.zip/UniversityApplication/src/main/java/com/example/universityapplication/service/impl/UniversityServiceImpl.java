package com.example.universityapplication.service.impl;

import com.example.universityapplication.pojo.dto.University;
import com.example.universityapplication.service.UniversityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class UniversityServiceImpl implements UniversityService {
    private final static String url = "http://universities.hipolabs.com/search";
    private final RestTemplate restTemplate;

    @Autowired
    public UniversityServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
    @Override
    public List<University> getAllUniversities() {

        return List.of(restTemplate.getForObject(url, University[].class));
    }

    public List<University> getUniversitiesByCountry(String country) {
        String formattedCountry = country.trim().replaceAll("\\s+"," ").replace(" ", "+");
        return List.of(restTemplate.getForObject(url + "?country=" + formattedCountry, University[].class));
    }

    @Override
    public List<University> getUniversitiesForMultipleCountries(List<String> country) {
        List<CompletableFuture<List<University>>> futures = country.stream().map(c->CompletableFuture.supplyAsync(()->getUniversitiesByCountry(c)))
                .collect(Collectors.toList());

        return futures.stream().map(CompletableFuture::join).flatMap(List::stream).collect(Collectors.toList());
    }


}
