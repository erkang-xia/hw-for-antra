package com.example.universityapplication.service;

import com.example.universityapplication.pojo.dto.University;

import java.util.List;

public interface UniversityService {

    List<University> getAllUniversities();
    List<University> getUniversitiesForMultipleCountries(List<String> country);
}
